import { motion } from 'framer-motion';
import { Pen } from 'lucide-react';

export function TypingIndicator() {
  return (
    <div className="flex justify-start mb-4">
      <div className="bg-[var(--bot-msg-bg)] border-2 border-[var(--border-color)] p-3 px-5 sketch-border flex items-center gap-2">
        <motion.div
          animate={{ 
            rotate: [0, 15, 0, -5, 0],
            x: [0, 2, 0, -2, 0]
          }}
          transition={{ 
            duration: 1.5, 
            repeat: Infinity, 
            ease: "easeInOut" 
          }}
          className="text-[var(--text-primary)]"
        >
          <Pen size={20} className="transform rotate-[-45deg]" />
        </motion.div>
        <span className="font-hand text-sm text-[var(--text-secondary)]">Anne is writing...</span>
      </div>
    </div>
  );
}
