import { useState } from 'react';
import { motion } from 'framer-motion';
import { Copy, Check } from 'lucide-react';
import { cn } from '@/utils/cn';

interface MessageBubbleProps {
  content: string;
  isUser: boolean;
  timestamp: string;
}

export function MessageBubble({ content, isUser, timestamp }: MessageBubbleProps) {
  const [copied, setCopied] = useState(false);

  const handleCopy = () => {
    navigator.clipboard.writeText(content);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 10, scale: 0.95 }}
      animate={{ opacity: 1, y: 0, scale: 1 }}
      transition={{ duration: 0.3, ease: "easeOut" }}
      className={cn(
        "flex w-full mb-4",
        isUser ? "justify-end" : "justify-start"
      )}
    >
      <div className="flex flex-col max-w-[80%]">
        <div
          className={cn(
            "relative p-4 sketch-border",
            isUser 
              ? "bg-[var(--user-msg-bg)] text-[var(--user-msg-text)] border-2 border-[var(--border-color)]" 
              : "bg-[var(--bot-msg-bg)] text-[var(--bot-msg-text)] border-2 border-[var(--border-color)]"
          )}
        >
          <p className="font-hand text-lg leading-relaxed whitespace-pre-wrap">{content}</p>
          
          <div className={cn(
            "flex items-center gap-2 mt-2",
            isUser ? "justify-end text-white/50" : "justify-start text-black/40 dark:text-gray-400"
          )}>
            <span className="text-xs font-hand mr-2">{timestamp}</span>
          </div>
        </div>

        {/* Message Actions - Always visible below bot messages */}
        {!isUser && (
          <div className="flex items-center gap-1 mt-2 ml-2">
            <button 
              onClick={handleCopy}
              className="flex items-center gap-1 px-2 py-1 text-xs font-hand text-[var(--text-secondary)] hover:bg-[var(--hover-bg)] rounded transition-all"
              aria-label="Copy message"
            >
              {copied ? <Check size={12} /> : <Copy size={12} />}
              <span>{copied ? 'Copied' : 'Copy'}</span>
            </button>
          </div>
        )}
      </div>
    </motion.div>
  );
}
