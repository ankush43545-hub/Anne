import { ThemeProvider } from './context/ThemeContext';
import { ChatInterface } from './components/Chat/ChatInterface';

export function App() {
  return (
    <ThemeProvider>
      <div className="min-h-screen flex justify-center bg-[var(--bg-secondary)]">
        <div className="w-full max-w-md h-full shadow-xl bg-[var(--bg-primary)]">
          <ChatInterface />
        </div>
      </div>
    </ThemeProvider>
  );
}
