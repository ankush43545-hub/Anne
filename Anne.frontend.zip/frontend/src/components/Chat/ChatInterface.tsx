import { useState, useRef, useEffect } from 'react';
import { Send, ArrowLeft, Menu, Moon, Sun, Download, Trash2, Users } from 'lucide-react';
import { MessageBubble } from './MessageBubble';
import { TypingIndicator } from './TypingIndicator';
import { ScribbleButton } from '../ui/ScribbleButton';
import { DropdownMenu, MenuItem, MenuDivider } from '../ui/DropdownMenu';
import { useTheme } from '@/context/ThemeContext';
import { motion } from 'framer-motion';

const API_URL = 'https://anne-io.onrender.com';

interface Message {
  id: string;
  content: string;
  isUser: boolean;
  timestamp: string;
}

interface ChatSession {
  id: string;
  messages: Message[];
  createdAt: string;
  updatedAt: string;
}

// Generate a random session ID
function generateSessionId(): string {
  return Math.random().toString(36).substring(2, 15) + Math.random().toString(36).substring(2, 15);
}

// Get session ID from URL
function getSessionIdFromUrl(): string | null {
  const params = new URLSearchParams(window.location.search);
  return params.get('session');
}

// Update URL with session ID
function updateUrlWithSession(sessionId: string) {
  const url = new URL(window.location.href);
  url.searchParams.set('session', sessionId);
  window.history.replaceState({}, '', url.toString());
}

export function ChatInterface() {
  const [sessionId, setSessionId] = useState<string>(() => {
    const urlSession = getSessionIdFromUrl();
    return urlSession || generateSessionId();
  });
  const [messages, setMessages] = useState<Message[]>([]);
  const [inputValue, setInputValue] = useState('');
  const [isTyping, setIsTyping] = useState(false);
  const [isOnline, setIsOnline] = useState(true);
  const [isSharedSession, setIsSharedSession] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const { theme, toggleTheme } = useTheme();

  // Initialize session
  useEffect(() => {
    const urlSession = getSessionIdFromUrl();
    if (urlSession) {
      setSessionId(urlSession);
      setIsSharedSession(true);
      loadSession(urlSession);
    } else {
      // New session - update URL
      const newSessionId = generateSessionId();
      setSessionId(newSessionId);
      updateUrlWithSession(newSessionId);
      // No welcome message - start empty
      saveSession(newSessionId, []);
    }
  }, []);

  // Save session whenever messages change
  useEffect(() => {
    if (sessionId) {
      saveSession(sessionId, messages);
    }
  }, [messages, sessionId]);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages, isTyping]);

  // Check backend status on mount
  useEffect(() => {
    checkBackendStatus();
    const interval = setInterval(checkBackendStatus, 30000);
    return () => clearInterval(interval);
  }, []);

  const checkBackendStatus = async () => {
    try {
      const response = await fetch(`${API_URL}/health`, { method: 'GET' });
      setIsOnline(response.ok);
    } catch {
      setIsOnline(false);
    }
  };

  // Save session to localStorage (and optionally backend)
  const saveSession = async (sid: string, msgs: Message[]) => {
    const session: ChatSession = {
      id: sid,
      messages: msgs,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString()
    };
    
    // Save to localStorage
    localStorage.setItem(`anne-session-${sid}`, JSON.stringify(session));
    
    // Try to save to backend if available
    try {
      await fetch(`${API_URL}/session`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(session),
      });
    } catch {
      // Backend not available, localStorage is sufficient
    }
  };

  // Load session from localStorage or backend
  const loadSession = async (sid: string) => {
    // Try localStorage first
    const saved = localStorage.getItem(`anne-session-${sid}`);
    if (saved) {
      const session: ChatSession = JSON.parse(saved);
      setMessages(session.messages);
      return;
    }
    
    // Try backend
    try {
      const response = await fetch(`${API_URL}/session/${sid}`);
      if (response.ok) {
        const session: ChatSession = await response.json();
        setMessages(session.messages);
        // Save to localStorage for future use
        localStorage.setItem(`anne-session-${sid}`, JSON.stringify(session));
      }
    } catch {
      // Session not found
    }
  };

  const handleSend = async () => {
    if (!inputValue.trim()) return;

    const userMessage: Message = {
      id: Date.now().toString(),
      content: inputValue,
      isUser: true,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
    };

    setMessages(prev => [...prev, userMessage]);
    setInputValue('');
    setIsTyping(true);

    try {
      const response = await fetch(`${API_URL}/chat`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          message: inputValue,
          conversationId: sessionId,
          sessionId: sessionId
        }),
      });

      if (!response.ok) throw new Error('Backend error');

      const data = await response.json();
      
      const botMessage: Message = {
        id: (Date.now() + 1).toString(),
        content: data.response || data.message || "I'm thinking... let me write that down.",
        isUser: false,
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
      };
      
      setMessages(prev => [...prev, botMessage]);
    } catch (error) {
      // Fallback to local responses if backend fails
      const fallbackResponses = [
        "That's so interesting! Tell me more.",
        "I've made a note of that.",
        "It feels like a cozy day for writing, doesn't it?",
        "I understand completely. Sometimes we just need to scribble our thoughts down.",
        "What else are you thinking about?",
        "Keep going, I'm listening...",
        "I love how you put that."
      ];
      
      const randomResponse = fallbackResponses[Math.floor(Math.random() * fallbackResponses.length)];
      
      const botMessage: Message = {
        id: (Date.now() + 1).toString(),
        content: randomResponse,
        isUser: false,
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
      };
      
      setMessages(prev => [...prev, botMessage]);
    } finally {
      setIsTyping(false);
    }
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSend();
    }
  };

  const handleExportChat = () => {
    const chatText = messages.map(m => 
      `[${m.timestamp}] ${m.isUser ? 'You' : 'Anne'}: ${m.content}`
    ).join('\n\n');
    
    const blob = new Blob([chatText], { type: 'text/plain' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `anne-chat-${new Date().toISOString().split('T')[0]}.txt`;
    a.click();
    URL.revokeObjectURL(url);
  };

  const handleClearChat = () => {
    if (confirm('Are you sure you want to clear this conversation?')) {
      setMessages([]);
      saveSession(sessionId, []);
    }
  };

  return (
    <div className="flex flex-col h-[100dvh] max-w-md mx-auto bg-[var(--bg-primary)] shadow-2xl relative overflow-hidden border-x-2 border-[var(--border-color)]/10 transition-colors duration-300">
      {/* Header */}
      <header className="flex items-center justify-between p-4 border-b-2 border-[var(--border-color)] bg-[var(--bg-card)] sticky top-0 z-10 sketch-border-sm mb-2 mt-2 mx-2">
        <button className="p-2 hover:bg-[var(--hover-bg)] rounded-full transition-colors">
          <ArrowLeft className="w-6 h-6" />
        </button>
        <div className="text-center">
          <h1 className="text-2xl font-bold font-hand">Anne</h1>
          <div className="flex items-center justify-center gap-1">
            <div 
              className={`w-2 h-2 rounded-full animate-pulse ${isOnline ? 'bg-black dark:bg-white' : 'bg-gray-400'}`} 
            />
            <span className="text-xs text-[var(--text-secondary)] font-hand">
              {isOnline ? 'Online' : 'Offline'}
            </span>
          </div>
          {isSharedSession && (
            <div className="flex items-center justify-center gap-1 mt-1">
              <Users size={10} className="text-[var(--text-secondary)]" />
              <span className="text-[10px] text-[var(--text-secondary)] font-hand">Shared Session</span>
            </div>
          )}
        </div>
        
        {/* Three-dot menu with functionality */}
        <DropdownMenu 
          trigger={<Menu className="w-6 h-6" />}
          align="right"
        >
          <MenuItem 
            onClick={toggleTheme} 
            icon={theme === 'light' ? <Moon size={18} /> : <Sun size={18} />}
          >
            {theme === 'light' ? 'Dark Mode' : 'Light Mode'}
          </MenuItem>
          
          <MenuDivider />
          
          <MenuItem onClick={handleExportChat} icon={<Download size={18} />}>
            Export Chat
          </MenuItem>
          
          <MenuDivider />
          
          <MenuItem 
            onClick={handleClearChat} 
            icon={<Trash2 size={18} />}
            danger
          >
            Clear Chat
          </MenuItem>
        </DropdownMenu>
      </header>

      {/* Shared Session Banner */}
      {isSharedSession && (
        <motion.div 
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          className="mx-4 mb-2 p-2 bg-[var(--bg-card)] border border-[var(--border-color)] rounded-lg sketch-border-sm"
        >
          <p className="text-xs text-center text-[var(--text-secondary)] font-hand">
            You're viewing a shared conversation. Feel free to continue chatting!
          </p>
        </motion.div>
      )}

      {/* Messages Area */}
      <div className="flex-1 overflow-y-auto p-4 space-y-4 scroll-smooth">
        {messages.length === 0 && !isTyping ? (
          <div className="flex flex-col items-center justify-center h-full opacity-50">
            <p className="text-xl font-hand text-[var(--text-secondary)] text-center">
              Let's fill up the notebook...
            </p>
          </div>
        ) : (
          messages.map((msg) => (
            <MessageBubble
              key={msg.id}
              content={msg.content}
              isUser={msg.isUser}
              timestamp={msg.timestamp}
            />
          ))
        )}
        {isTyping && <TypingIndicator />}
        <div ref={messagesEndRef} />
      </div>

      {/* Input Area */}
      <div className="p-4 bg-[var(--bg-card)] border-t-2 border-[var(--border-color)] z-10">
        <div className="flex items-end gap-2 bg-[var(--bg-primary)] border-2 border-[var(--border-color)] p-2 sketch-border">
          <textarea
            value={inputValue}
            onChange={(e) => {
              setInputValue(e.target.value);
              e.target.style.height = 'auto';
              e.target.style.height = `${e.target.scrollHeight}px`;
            }}
            onKeyDown={handleKeyDown}
            placeholder="Write a message..."
            className="flex-1 bg-transparent border-none outline-none resize-none font-hand text-lg max-h-32 min-h-[44px] py-2 px-2 text-[var(--text-primary)] placeholder:text-[var(--text-secondary)]"
            rows={1}
          />
          <ScribbleButton 
            onClick={handleSend}
            disabled={!inputValue.trim()}
            className="p-2 mb-1 !rounded-full !px-2 aspect-square flex items-center justify-center"
          >
            <Send className="w-5 h-5 ml-0.5 mt-0.5" />
          </ScribbleButton>
        </div>
      </div>
    </div>
  );
}
