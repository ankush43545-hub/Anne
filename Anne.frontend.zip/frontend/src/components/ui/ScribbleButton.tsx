import React from 'react';
import { cn } from '@/utils/cn';

interface ScribbleButtonProps extends React.ButtonHTMLAttributes<HTMLButtonElement> {
  variant?: 'primary' | 'secondary' | 'ghost';
}

export function ScribbleButton({ 
  className, 
  variant = 'primary', 
  children, 
  ...props 
}: ScribbleButtonProps) {
  return (
    <button
      className={cn(
        "relative px-4 py-2 font-hand text-lg transition-transform active:scale-95 disabled:opacity-50 disabled:cursor-not-allowed outline-none focus:ring-2 focus:ring-black/20 sketch-border-sm select-none",
        variant === 'primary' && "bg-black text-white border-2 border-transparent",
        variant === 'secondary' && "bg-transparent text-black border-2 border-black",
        variant === 'ghost' && "bg-transparent text-black hover:bg-black/5",
        className
      )}
      {...props}
    >
      {children}
    </button>
  );
}
