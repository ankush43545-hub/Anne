# Anne's Notebook - Frontend

A beautiful, handwritten-style chat interface for Anne chatbot.

## Features

- 📝 Handwritten notebook aesthetic
- 🌓 Light/Dark theme support
- 💬 Real-time chat with Anne AI
- 🔗 Shareable conversation sessions
- 💾 Auto-save conversations to localStorage
- 📥 Export chat history
- 🎨 Sketch-style borders and animations

## Backend Connection

The frontend is connected to: **https://anne-io.onrender.com**

The API URL is hardcoded in `src/components/Chat/ChatInterface.tsx` (line 10):
```typescript
const API_URL = 'https://anne-io.onrender.com';
```

## Setup

1. Install dependencies:
```bash
npm install
```

2. Run development server:
```bash
npm run dev
```

3. Build for production:
```bash
npm run build
```

## Environment Variables (Optional)

You can optionally use environment variables by creating a `.env` file:

```bash
cp .env.example .env
```

Then update `ChatInterface.tsx` to use:
```typescript
const API_URL = import.meta.env.VITE_API_URL || 'https://anne-io.onrender.com';
```

## Project Structure

```
src/
├── components/
│   ├── Chat/
│   │   ├── ChatInterface.tsx    # Main chat component
│   │   ├── MessageBubble.tsx    # Individual message component
│   │   └── TypingIndicator.tsx  # Typing animation
│   └── ui/
│       ├── DropdownMenu.tsx     # Menu component
│       └── ScribbleButton.tsx   # Custom button
├── context/
│   └── ThemeContext.tsx         # Theme management
├── utils/
│   └── cn.ts                    # Utility functions
├── App.tsx                      # Root component
├── main.tsx                     # Entry point
└── index.css                    # Global styles
```

## Deployment

### Vercel (Recommended)
```bash
npm run build
vercel --prod
```

### Netlify
```bash
npm run build
# Upload dist/ folder to Netlify
```

### GitHub Pages
Add to `vite.config.ts`:
```typescript
export default defineConfig({
  base: '/your-repo-name/',
  // ... rest of config
})
```

## Tech Stack

- React 19
- TypeScript
- Vite
- Tailwind CSS 4
- Framer Motion
- Lucide React Icons

## Session Sharing

Sessions are automatically saved and can be shared via URL:
```
https://your-app.com/?session=abc123
```

## Customization

### Change Theme Colors

Edit `src/index.css` to customize colors:
```css
:root {
  --bg-primary: #fdfbf7;
  --text-primary: #1a1a1a;
  /* ... more variables */
}
```

### Change Backend URL

Update line 10 in `src/components/Chat/ChatInterface.tsx`:
```typescript
const API_URL = 'https://your-backend-url.com';
```
